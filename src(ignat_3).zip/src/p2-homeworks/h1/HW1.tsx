import React from 'react'
import {Message} from "./Message";

const messageData = {
    avatar: "https://www.pngitem.com/pimgs/m/421-4213036_avatar-hd-png-download.png",
    name: 'Some Name',
    message: "По умолчанию все предметы располагаются вдоль главной оси — слева направо. Именно поэтому блоки в предыдущем примере выстроились в линию, когда мы применили display: flex. А вот flex-direction позволяет вращать главную ось.",
    time: '22:00',
}

function HW1() {
    return (
        <div>
            <hr/>
            homeworks 1
            should work (должно работать)
            <hr/>
            <Message
                avatar={messageData.avatar}
                name={messageData.name}
                message={messageData.message}
                time={messageData.time}
            />
            <hr/>
            {/*для личного творчества, могу проверить*/}
            {/*<AlternativeMessage/>*/}
            <hr/>
        </div>
    )
}

export default HW1
