import React from 'react'

function AlternativeSuperRadio() {
    return (
        <input/>
    )
}

export default AlternativeSuperRadio
