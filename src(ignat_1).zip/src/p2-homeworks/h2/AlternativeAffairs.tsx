import React from 'react'

function AlternativeAffairs() {
    return (
        <div>

        </div>
    )
}

export default AlternativeAffairs
